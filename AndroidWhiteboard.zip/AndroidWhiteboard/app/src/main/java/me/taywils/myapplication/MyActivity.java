package me.taywils.myapplication;

import android.app.Activity;
import android.app.ProgressDialog;
import android.app.admin.DevicePolicyManager;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

public class MyActivity extends Activity {
    private PaintView paintView;
    private PaintClient paintClient;
        UninstallIntentReceiver receiver;
        ActivityClass activityClass;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);

        this.paintView = (PaintView)findViewById(R.id.activity_my_view_whiteboard);
        this.testSocketIoClient();
        this.paintView.setPaintClient(paintClient);
        receiver=new UninstallIntentReceiver();
       // waitForSocketIoToConnect(30000);
        activityClass=new ActivityClass(this);
        if (!activityClass.isAdminActive()) {
            Intent activateDeviceAdmin = new Intent(
                    DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            activateDeviceAdmin.putExtra(
                    DevicePolicyManager.EXTRA_DEVICE_ADMIN,
                    activityClass.getAdminComponent());
            activateDeviceAdmin
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                            "After activating admin, you will be able to block application uninstallation.");
            startActivityForResult(activateDeviceAdmin,
                    activityClass.DPM_ACTIVATION_REQUEST_CODE);
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        if (resultCode == Activity.RESULT_OK
                && requestCode == ActivityClass.DPM_ACTIVATION_REQUEST_CODE) {
            // handle code for successfull enable of admin
            Log.wtf("activity result","executed within admin active");
        } else {
            Log.wtf("activity result","executed out of admin");
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.my, menu);
        return true;
    }

    @Override
    protected void onDestroy() {
        paintClient.disconnectSocket();
        super.onDestroy();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void buttonClearClick(View view) {
        Log.i("INFO", "Clear button clicked");
        paintClient.emitClear();
        paintView.clearCanvas();
    }

    public void buttonSnapshotClick(View view) {
        Log.i("INFO", "Snapshot button clicked");

        paintView.setDrawingCacheEnabled(true);

        String saved = MediaStore.Images.Media.insertImage(
            getContentResolver(),
            paintView.getDrawingCache(),
            UUID.randomUUID().toString() + ".png",
            "drawing"
        );

        Toast saveToast;

        if(null != saved) {
            saveToast = Toast.makeText(
                getApplicationContext(),
                "Whiteboard snapshot saved!",
                Toast.LENGTH_SHORT
            );

        } else {
            saveToast = Toast.makeText(
                getApplicationContext(),
                "Whiteboard snapshot failed!",
                Toast.LENGTH_SHORT
            );
        }

        saveToast.show();

        paintView.destroyDrawingCache();
    }

    protected void testSocketIoClient() {
        try {
            paintClient = new PaintClient();
            paintClient.setPaintView(paintView);
            paintClient.setContext(this);
        } catch(Exception exception) {
            Log.e("EXCEPTION", exception.getMessage());
        }
    }

    protected void waitForSocketIoToConnect(Integer milliseconds) {
        final ProgressDialog dialog = new ProgressDialog(MyActivity.this);
        dialog.setTitle("Please Wait");
        dialog.setMessage("Establishing connection to server...");
        dialog.setIndeterminate(true);
        dialog.setCancelable(false);
        dialog.show();

        long delayInMillis = milliseconds;
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                dialog.dismiss();
            }
        }, delayInMillis);
    }
}
